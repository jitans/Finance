`pairs.stockReturns` <-
function(x, col='#00000018', ...){
	pairs(x$R, col=col, ...)
}

